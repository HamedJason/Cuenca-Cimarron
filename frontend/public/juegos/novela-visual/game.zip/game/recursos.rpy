init python:
    renpy.music.register_channel("dialogo", "sound", loop=False)

    def sonido_narrador(event, interact=True, **kwargs):
        if event == "begin":
            renpy.music.play("audio/D.mp3", channel="dialogo")

    def sonido_personaje(event, interact=True, **kwargs):
        if event == "begin":
            renpy.music.play("audio/Personaje.mp3", channel="dialogo")


define narrator = Character(None, callback=sonido_narrador)

####DEFINICION DE PERSONAJES
define amigo = Character("Amigo", callback=sonido_personaje)
define amiga = Character("Amiga", callback=sonido_personaje)
define jugador = Character("[name_p]", callback=sonido_personaje)
define FIN = Character("FIN", callback=sonido_personaje)
define chancho = Character("Chancho", callback=sonido_personaje)
define vecino = Character("Vecino", callback=sonido_personaje)
define no911 = Character("Operador 911", callback=sonido_personaje)
define mama = Character("Mamá", callback=sonido_personaje)



##PERSONAJES
image amigap1 = "images/PERSONAJES/AMIGA 2.png"
image amigop1 = "images/PERSONAJES/AMIGO 1.png"
image mama = "images/PERSONAJES/MAMA.png"
image chancho = "images/PERSONAJES/CHANCHO.png"
image chanchoz = "images/PERSONAJES/CHANCHOZ.png"
image vecino = "images/PERSONAJES/VECINO.png"
image amigocelu = "images/PERSONAJES/AMIGOCELU.png"
image celu911 = "images/PERSONAJES/CELU911.png"

#FONDOS
image SALON = "images/FONDOS/SALON.png"
image ESTACIONAMIENTO = "images/FONDOS/ESTACIONAMIENTO.png"
image CARRO1 = "images/FONDOS/CARROLL1.png"
image CARRO2 = "images/FONDOS/CARROLL2.png"
image NEGRO = "images/FONDOS/NEGRO.webp"
image CASA = "images/FONDOS/CASA.png"
image VENTANA = "images/FONDOS/VENTANA.png"
image CALLE = "images/FONDOS/CALLE.png"

#EXTRAS
image cartel = "images/EXTRA/Anuncio.jpg"
image celular = "images/EXTRA/CELU.png"
