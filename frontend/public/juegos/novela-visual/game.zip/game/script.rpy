﻿# Coloca el código de tu juego en este archivo.

# Declara los personajes usados en el juego como en el ejemplo:


# El juego comienza aquí.

label start:

    stop music fadeout 1.0

    "¿Cómo te gustaría que te llamen?"

    $name_p=renpy.input("Escribe tu nombre")

    if name_p == "":
        $name_p = "Jugador"

    "Mucho gusto, [name_p], disfruta de la experiencia."
   
#####ESCENA DENTRO DEL SALON DE CLASES####
    scene SALON
    play sound "audio/Timbre.mp3" fadein 0.3
 

    "Después de un lluvioso día en la escuela, tus clases terminan exactamente a las 6PM."

    show amigop1
    amigo "No puedo creer que el maestro se tomará exactamente las 2 horas clase."

    show amigap1
    amiga "¡Exacto! más con la lluvia que ya lleva rato!"
    amiga "¿Acaso no sabe lo mal que se ponen las calles después de que caen tres gotas en esta ciudad?"
   
    hide amigap1
    hide amigop1

    "Tú y tus amigos siguen platicando sin rumbo un par de minutos hasta que uno de ellos muestra algo en su celular."
    


    show amigop1
    amigo "¿Oigan ya vieron lo que publicaron en la facultad?"
    amigo "Es sobre el fenómeno del Niño."

    "Miras el anuncio en el celular."
    call screen ver_cartel
   
    amigo "Se supone que hoy llegaba algo fuerte."

    show amigap1

    "Todos miran con detenimiento la publicación."
    "Puede que sea información útil para el futuro."

    amiga "Chanfle y yo que aun tengo que recoger a mi hermano de la escuela a las 7."

    amigo "Que mala suerte la tuya jaja."

    amiga "¡Ya basta! no se rían."

    amigo "Bueno jaja, yo ya me voy porque ya va a llegar mi camión."
    amigo "¡Suerte con la lluvia chicos!"

    amiga "¡Adióssss!"

    hide amigop1
    
    amiga "Lo siento [name_p] me gustaría seguir platicando pero ya me tengo que ir antes de que se haga más tráfico."
    amiga "Tu deberías hacer lo mismo, no te vayas a quedar atrapado en la tormenta."
    amiga "Jaja cuidado con tu carro chaparro y los charcos."


####ESCENA EN EL ESTACIONAMIENTO DE LA FACULTAD####

    scene ESTACIONAMIENTO
    "Tú y tu amiga se despiden en la entrada del estacionamiento de la facultad y toman caminos diferentes."
    "Subes a tu carro {i}chaparro{/i}, según tu amiga, y sales del campus."

#### ESCENA EN EL CARRO####
    scene CARRO1
    play music "audio/LluviaCarro.mp3" fadein 0.3

    "El camino es algo largo pero te motiva saber que al llegar te espera tu perrito “Chancho” con mucho entusiasmo."
    "Por un rato no observas mucho tráfico entonces vas a una velocidad moderada, sin embargo más adelante te das cuenta que en la bajada de la calle hay una laguna que cubre todos los carriles a lo ancho de la calle."
    "¿Qué harás?"

    menu:
        "Seguir con tu velocidad normal y pasar sin perder el tiempo":
            play sound "audio/AutoAc.mp3" fadein 2
            "Wujuu pasaste sin ningún problema y hasta le salpicaste a otro carro cercano."
            "Pero no le tomas importancia porque significa que vas a ver a Chancho más rápido."
            
            play sound "audio/CarroOff.mp3" fadein 0.5
            "...."

            jugador "Oh…?"

            "De un momento a otro tu carro deja de marchar y te quedas varado a unos metros de la laguna."
            "Salpicaste agua de forma que entró a tu motor y lo dejó inhabil por unas horas."
            stop music fadeout 0.5

            scene NEGRO
            FIN "{b}FINAL 1: Hidrobloqueo{/b} \nNo llegaste a casa a tiempo y por no bajar la velocidad no pudiste ver a tu perrito Chancho esa noche."
            return
        
        "Pasar con una velocidad baja y constante con precaución":
            "Bajaste la velocidad de tu carro y pasaste sin levantar el agua de la laguna."
            "Al lado de ti pasa un carro similar al tuyo a la misma velocidad a la que ibas tú anteriormente."
            "Al pasar, te salpica."

            jugador "Nooo ya me salpicó este."

            "No pasan muchos metros hasta que lo alcanzas."
            "Miras que su carro está detenido y no puede prenderse."
            "Al parecer le entró agua."

            jugador "Uy… que bueno que no soy ese."

            scene CARRO2

            "Continúas con tu camino como de costumbre."
            "De repente el tráfico va más lento de lo normal e intentas mirar más allá de los carros delante de ti."

            "Observas que hay un encharcamiento que cubre a todo un carril."
############### FOTO DE CHARCO 
            jugador "Ah, entonces eso era..."

            "Podrías pasar por el charco, después de todo no se ve muy hondo, o rodearlo como el resto de carros, aunque tardarías unos minutos extra esperando tu turno."

            menu:
                "Cambiar de carril y pasar por el charco con precaución":
                    "Decides pasar por el charco con precaución a que no te salpique el agua."
                    play sound "audio/CaidaAgua.mp3" fadein 0.5
                    "(Golpe fuerte)"

                    jugador "¡¿Qué fue eso?!"

                    "Quedas inmóvil dentro del charco."
                    "No sabes qué pasa, entonces decides salir a dar un vistazo."
                    "Bajas y te mojas todo el cuerpo al salir a inspeccionar."

                    jugador "¡Ahh…de todas las cosas!"

                    "No tardas mucho en darte cuenta que caíste en una alcantarilla abierta."
                    "Por la lluvia no se notaba que estuviera abierta."

                    stop music fadeout 0.5  
                    scene NEGRO
                    FIN "{b}FINAL 2: Atascado{/b} \nNo llegaste a casa a tiempo y por un descuido no pudiste ver a tu perrito Chancho esa noche esperando a una grúa."
                    return

                "Quedarte en tu carril y esperar tu turno para rodear el charco":
                    "Tardas un poco esperando tu turno…"
                    "Finalmente llega y puedes rodear el charco."
                    "Mientras pasas a un lado, puedes ver cómo un carro parece hundido en el charco que a simple vista no parecía hondo."

                    jugador "Sin duda es mejor evitar todos los charcos posibles con este clima…"

                    "Continúas con tu camino como de costumbre…"
                    "Tardas un poco más de lo normal pero a la distancia ya puedes ver tu casa."
                    "Mientras más te acercas, puedes ver que está iluminada por dentro."
                    "Tu madre ha de haber vuelto temprano de trabajar."
                    scene NEGRO
                    "Llegas al estacionamiento de tu casa y te preparas mentalmente para salir a la lluvia."

            stop music fadeout 0.5
###SALIENDO DEL CARRO#####

            play music "audio/Lluvia.mp3" fadein 0.5
            jugador "¡AAAAAAAH!"

            "Caminas lo más rápido que puedes porque de otra forma es probable que caigas y tires tus pertenencias."
            "Desafortunadamente terminas empapado cuando llegas a la entrada de tu casa, pero finalmente llegaste a casa."
            "Abres la puerta y te recibe la cálida luz de tu hogar."
            stop music fadeout 0.5
#######ESCENA CASA#####

            scene CASA
            play sound "audio/Puerta.mp3" fadein 0.5 

            show chancho 
            chancho "¡ARF ARF!"

            "Miras hacia abajo y encuentras a tu perrito Chancho saltando y jadeando para que lo cargues."
            jugador "¡Waaa Chanchooooo!"
            jugador "No sabes el caos que hay allá afuera, ojalá fuera tú."
            jugador "Todo el día con tus juguetes, comida y cama disponible."
            jugador "Ahh que envidia."
            hide chancho

            "Sigues jugando y dándole cariño a Chancho hasta que tu madre sale a saludarte."
            show mama

            mama "Hasta que llegas  [name_p], creí que te había pasado algo."

            jugador "No no te preocupes, fue por la tormenta que está afuera que todo iba mucho más lento."
            jugador "Por cierto me mostró hace rato un amigo esta publicación."

            call screen ver_cartel

            mama "Es cierto es por lo del fenómeno del Niño."
            mama "No sería mala idea preparar las mochilas que comentan en la publicación."
            mama "Y aprovechando que estamos en casa, igual hay que prepararla en caso de un apagón."

            jugador "Está bien, prepararé la mochila y no sé si tú quieres encargarte de preparar la casa por el apagón."

            mama "Uyyy… sobre eso, ¿crees que te puedas encargar de las dos cosas?"
            mama "Me dejaron salir antes de la oficina por la tormenta, pero aun tengo trabajo pendiente que hacer en mi cuarto."

            jugador "Oh..."
            jugador "Está bien mamá, lo haré pero primero voy a secarme que vengo empapado… jaja"

            mama "Ahh muchas gracias cariño, mañana te lo repongo, ¡nos vemos!"
###ESCENA VECINO#####
            scene NEGRO
            "Quedándote solo en la entrada de tu casa te diriges al baño y te preparas para empezar con tus nuevas tareas."
            "Terminas de arreglarte y decides con iniciar preparando la mochila de emergencias."

            jugador "Oh...?"

            "Antes de continuar, escuchas algunas voces provenientes de la calle."

            scene ventana
            "Te acercas a una ventana para observar qué sucede y reconoces a uno de tus vecinos."
            "Al parecer, un cable eléctrico ha caído sobre la calle mojada y el vecino intenta retirarlo utilizando un palo."

            scene NEGRO
            play sound "audio/Puerta.mp3" fadein 0.5  
            "Sales rápidamente con un paraguas de la entrada."

            scene CALLE
            play music "audio/Tormenta.mp3" fadein 0.5
            play sound "audio/Cable.mp3" fadein 1.5
            jugador "¡Esperese! ¡No toque ese cable!"

            show vecino
            vecino "Solo quiero quitarlo para que puedan pasar los automóviles."
            play sound "audio/Cable.mp3" fadein 1.5
            jugador "¡Podría tener electricidad! Es muy peligroso don."

            vecino "¿Entonces qué sugieres?"

            menu:
                "Utilizar un objeto de madera para mover el cable":
                    hide vecino
                    "¡Cuidado! Aunque la madera puede parecer un material aislante, no es seguro utilizarla para mover un cable eléctrico."
                    "Podrías sufrir una descarga eléctrica. Lo correcto es mantenerte alejado y reportar la situación."
                    
                    jugador "Ahh eso suena como una mala idea."
                    jugador "Tendre que pensar en otra cosa..."

                    

                    scene NEGRO
                    FIN "{b}FINAL 3: Riesgo innecesario{/b} \nEvita lo mas que puedas el contacto con cables sueltos, podrías salir múy lastimado."

                    return


                "Alejarse, advertir a los demás sin acercarse y reportar el peligro al 911":
                    play sound "audio/Cable.mp3" fadein 1.5
                    "Decides mantenerte alejado del cable y adviertes al vecino que no debe acercarse."
                    "También evitas que otras personas transiten por esa zona y reportas el peligro al 911."
                    "Recuerda que nunca debes intentar mover un cable eléctrico caído, aunque parezca inofensivo."
                    
                    

                    jugador "Ya todo esta bajo control don, las autoridades lo manejarán."
                    vecino "Oh okay joven, muchas gracias por la ayuda."

                    "Después de asegurarte de que el vecino se mantenga alejado, regresas al interior de tu casa."
                    hide vecino
                    stop music fadeout 1.5
                    "Definitivamente, esta tormenta está ocasionando más problemas de los que imaginabas."

    ###DE REGRESO A CASA####

                    scene CASA
                    play sound "audio/Puerta.mp3" fadein 0.5 
                    "Regresas a casa y recuerdas que todavía tienes pendiente preparar tu mochila de emergencia."
                    "Pasan los minutos y mientras buscas los artículos que necesitas guardar, escuchas una notificación de tu celular."
                    play sound "audio/Notif.mp3"
                    "Es uno de tus amigos, quién parece bastante preocupado por la intensidad de la lluvia."

                    play sound "audio/Notif.mp3"
                    show amigocelu
                    amigo "¡Está lloviendo muchísimo! ¡Voy a llamar al 911!"

                    jugador "Espera, no hay ninguna emergencia hasta el momento como tal."

                   
                    play sound "audio/Notif.mp3"
                    amigo "Pero ¿cómo sabemos si va a empeorar?"

                    jugador "Podemos revisar los avisos oficiales y tomar precauciones."

                    menu:
                        "Llamar al 911 para preguntar cuánto tiempo seguirá lloviendo":
                            scene NEGRO
                            "El 911 está destinado a atender emergencias, no a proporcionar pronósticos meteorológicos."
                            "Realizar llamadas innecesarias puede dificultar la atención de personas que realmente necesitan ayuda."

                            jugador "Es cierto, no deberíamos dejarnos influenciar por el pánico..."
                            FIN "{b}FINAL 4: Llamada mortal{/b} \nEs ideal informarse acerca de cuales son los casos en los que es necesario contactar al 911."
                            FIN "Podrías perjudicar a las personas que realmente los necesitan."
                            
                            return

                        "Consultar los avisos meteorológicos oficiales, permanecer en un lugar seguro y preparar su plan familiar de emergencia":
                            "¡Exactamente!"
                            "Decides revisar los avisos oficiales para mantenerte informado y aconsejas a tu amigo."

                            jugador "Oye te acabo de mandar una pagina oficial donde publican sobre el clima y las alertas de la ciudad."
                            jugador "No te dejes llevar por el pánico y mantente en un lugar seguro."
                            
                            play sound "audio/Notif.mp3"
                            amigo "Está bien..."
                            play sound "audio/Notif.mp3"
                            amigo "Y muchas gracias, te debo una soda la próxima vez que nos veamos."

                            "Se despiden y continúas con la preparación de tú mochila de emergencia."
                            
                            scene NEGRO
                            "Finalmente, terminas de reunir los artículos necesarios para tu mochila de emergencia."

                            "Cuando estás por terminar de organizar tus cosas, recibes un mensaje en el grupo vecinal."
                            "Al parecer, las lluvias han provocado inundaciones en algunas calles de la ciudad."
                            "Entre los mensajes encuentras el reporte de un automóvil atrapado en una zona inundada. Una persona podría encontrarse en su interior."
                            "Te preocupa la situación y decides comunicarte con el número de emergencias."
                            
                            play sound "audio/Llamada.mp3"
                            jugador "Ahh qué digo, qué hago..."

                            menu: 
                                "Tú opinión sobre por qué ocurrió la inundación":
                                    scene NEGRO 
                                    "El motivo por el que ocurrió la inundación no es la información prioritaria durante una llamada de emergencia."
                                    "Lo importante es describir los hechos, indicar la ubicación y comunicar si existen personas atrapadas o lesionadas."

                                    FIN "{b}FINAL 5: Llamada perdida{/b} \nDebes saber que información es importante proporcionar durante una llamada de emergencia, el tiempo es indispensable."

                                    return

                                "La ubicación exacta, qué sucedió, cuántas personas están involucradas y si hay lesionados":
                                    "Recuerdas que es importante mantener la calma y proporcionar información clara para que puedan enviar la ayuda necesaria."
                                    "Al igual que también es importante responder las preguntas del operador y seguir sus indicaciones."
                                    
                                    show celu911
                                    no911 "911, ¿cuál es su emergencia?"

                                    jugador "Si buenas noches. Hay una inundación en mi colonia y una persona está atrapada dentro de un automóvil."
                                    
                                    no911 "¿Me puede proporcionar su ubicación exacta?"
                                
                                    jugador "Sí, estamos en (calle, colonia y municipio), cerca de (referencia cercana)."

                                    no911 "Perfecto, ¿Hay personas lesionadas? ¿Cuántas personas están involucradas?"

                                    jugador "Hay una persona atrapada. No puedo confirmar si está lesionada."

                                    no911 "Entendido. Vamos a canalizar el apoyo correspondiente. Manténgase alejado de la corriente y siga nuestras indicaciones."

                                    jugador "De acuerdo, esperaré sus indicaciones."

                                    scene CASA
                                    "Después de proporcionar la información solicitada, sigues las indicaciones del operador y permaneces en un lugar seguro."
                                    "Te das cuenta de que saber cuándo llamar al 911 y cómo comunicar una emergencia puede marcar una gran diferencia."
                                    "Finalmente, miras a tu alrededor y recuerdas que todavía debes terminar de preparar tu casa."

                                    jugador "Hmmm, ¿qué me faltaba?"

                                    "Escuchas a tu mamá hablarte desde su cuarto"

                                    mama "¡PREPARAR LA CASA EN CASO DEL APAGÓN!"

                                    jugador "Ahh... cierto."

                                    "Ya querías irte a dormir."
                                    "Pero la tormenta no te esperará entonces sigues con tu labor."

                                    jugador "Veamos, qué es lo principal por hacer ante un apagón."
                                    
                                    menu:
                                        "Abrir las ventanas y ventilar la casa":
                                            jugador "Hmmm mala idea, es posible que se inhunde la casa."
                                        
                                        "Desconectar los aparatos electrónicos":
                                            jugador "Es cierto, debo desconectarlos o se pueden echar a perder cuando vuelva la luz por el repentino voltaje."
                                            jugador "Bueno, manos a la obra."
                                            
                                    scene NEGRO
                                    "Te toma múy poco tiempo desconectar los aparatos electrónicos necesarios."
                                    jugador "Cargadores, tele, microóndas, aire acondicionado, PC, impresora..."
                                    jugador "Creo que ya es todo a excepción del módem..."
                                    jugador "Mmmmmm pero que de eso se encargue mi mamá que aún lo necesita."

                                    "Después de un largo día, finalmente terminas de prepararte para la tormenta."
                                    "Llegas a tu cuarto y sobre tu cama se encuentra tu perrito Chancho dormido."

                                    jugador "Hola Chancho, jaja me ganaste."
                                    jugador "..."
                                    jugador "Hazte para un lado yo tambien quiero colchón."
                                    show chanchoz
                                    chancho "Z z z z z ..."
                                    jugador "Ok."

                                    "Con lo que te queda de paciencia, mueves a Chancho de forma que los dos terminan debajo de las cobijas."
                                    hide chanchoz
                                    jugador "Buenas noches Chancho."

                                    show chanchoz
                                    chancho "Z z z z .... !"
                                    "Chancho te lame la mano antes de volver a dormir profundamente."
                                    hide chanchoz
                                    "Minutos despúes te únes y duermes a su lado."
                                    
                                    FIN "{b}FINAL 6: Final verdadero{/b} \nCompletaste todas tus metas del día y ayudaste a los demás sin ningún problema, puede que sea el final de esta experiencia pero es importante seguir informados sobre lo que podría pasar en el futuro."
                                    FIN "Muchas gracias por jugar esta experiencia."
                                    FIN "Atte. Antonella y Jennyfer."


    # Finaliza el juego:

    return
